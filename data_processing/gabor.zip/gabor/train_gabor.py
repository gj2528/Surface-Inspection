import cv2,os
import numpy as np
import matplotlib.pyplot as plt
import csv
import codecs


input_Path = './new'
img_paths = []
for (path, dirs, files) in os.walk(input_Path):
    for filename in files:
        if filename.endswith(('.jpg','.png')):
            img_paths.append(path+'/'+filename)

lamda = np.pi/2.0         # 波长
kern = cv2.getGaborKernel((7, 7), 1.0, np.pi / 4, lamda, 0.5, 0, ktype=cv2.CV_32F)
kern /= 1.5*kern.sum()

for img in img_paths:
    print(img)
    img1 = cv2.imread(img)
    fimg = cv2.filter2D(img1, cv2.CV_8UC1, kern)
    plt.imshow(fimg)
    
    plt.axis('off')
    fig = plt.gcf()
    # fig.set_size_inches(7.0/3,7.0/3) #dpi = 300, output = 700*700 pixels
    plt.gca().xaxis.set_major_locator(plt.NullLocator())
    plt.gca().yaxis.set_major_locator(plt.NullLocator())
    plt.subplots_adjust(top = 1, bottom = 0, right = 1, left = 0, hspace = 0, wspace = 0)
    plt.margins(0,0)
    fig.savefig("new/ftr/"+img[6:], format='png', transparent=True, pad_inches = 0)

    #plt.savefig("feature/"+img[7:],bbox_inches = 'tight')
    #plt.show()
    



def get_img(input_Path):
    img_paths = []
    for (path, dirs, files) in os.walk(input_Path):
        for filename in files:
            if filename.endswith(('.jpg','.png')):
                img_paths.append(path+'/'+filename)
    return img_paths


#构建Gabor滤波器
def build_filters():
     filters = []
     ksize = [7] # gabor尺度，6个
     lamda = np.pi/2.0         # 波长
     #print("np.pi",np.pi)
     #print("lamda",lamda)
     theta =np.pi / 4
     for K in range(0,1):
         kern = cv2.getGaborKernel((ksize[K], ksize[K]), 1.0, theta, lamda, 0.5, 0, ktype=cv2.CV_32F)
         kern /= 1.5*kern.sum()
         filters.append(kern)
     plt.figure(1)

     #用于绘制滤波器
     for temp in range(len(filters)):
         
         plt.imshow(filters[temp])
     #plt.show()
     return filters

#Gabor特征提取
def getGabor(img, path, filters):
    res = [] #滤波结果
    #fig = plt.figure()
    for i in range(len(filters)):
        #res1 = process(img, filters[i])
        accum = np.zeros_like(img)
        for kern in filters[i]:
            fimg = cv2.filter2D(img, cv2.CV_8UC1, kern)
            accum = np.maximum(accum, fimg, accum)
            

        res.append(np.asarray(accum))
 

    #用于绘制滤波效果 
    plt.figure(2)
    for temp in range(len(res)):
        # plt.subplot(4,6,temp+1)
        plt.imshow(res[temp], cmap='gray' )
    plt.savefig("new/ftr/"+path[6:])
    #plt.show()
    return res  #返回滤波结果,结果为24幅图，按照gabor角度排列


if __name__ == '__main__':
    # input_Path = './new'
    # filters = build_filters()
    # img_paths = get_img(input_Path)
    # for img in img_paths:
    #     print(img)
    #     img1 = cv2.imread(img)
    #     getGabor(img1,img, filters)
    path = './new/ftr'
    datafile_path = './new/ftr/feature1.csv'
    area = 0
    feature_paths = get_img(path)
    # result = [id, ]
    #     out = codecs.open(datafile_path,'a','utf-8')
    #     csv_write = csv.writer(out,dialect='excel')
    #     csv_write.writerow(result)
    #     out.close()
    for feature in feature_paths:
        img = cv2.imread(feature)
        image=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        ret3,th3 = cv2.threshold(image,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)# 二值化 0 = black ; 1 = white
        height, width = th3.shape
        for i in range(height):
            for j in range(width):
                if th3[i, j] == 255:
                    area += 1
        result = [feature, area]
        out = codecs.open(datafile_path,'a','utf-8')
        csv_write = csv.writer(out,dialect='excel')
        csv_write.writerow(result)
        out.close()
        area = 0
